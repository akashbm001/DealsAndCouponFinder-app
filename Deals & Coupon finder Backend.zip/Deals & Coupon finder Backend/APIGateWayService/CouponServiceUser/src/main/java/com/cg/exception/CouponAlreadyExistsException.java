package com.cg.exception;

public class CouponAlreadyExistsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CouponAlreadyExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CouponAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}