package com.cg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Deals_Coupen_Finder_App_JWTServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
