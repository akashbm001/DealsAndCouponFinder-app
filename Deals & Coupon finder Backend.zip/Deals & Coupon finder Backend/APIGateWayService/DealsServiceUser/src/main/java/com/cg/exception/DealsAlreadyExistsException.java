package com.cg.exception;

public class DealsAlreadyExistsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DealsAlreadyExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DealsAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}